package com.iscas.iccbot;

public class ResumeUtil {
    protected class ResultDump {
        protected Global global;
        protected MyConfig myConfig;
        protected soot.G sootG;
    }
}
