package com.iscas.iccbot;

public enum SummaryLevel {
    none, path, object, flow
};
