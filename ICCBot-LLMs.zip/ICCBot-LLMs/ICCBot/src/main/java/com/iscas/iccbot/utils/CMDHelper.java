package com.iscas.iccbot.utils;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

@Slf4j
public class CMDHelper {
//    private static final Logger log = LoggerFactory.getLogger(CMDHelper.class);

    public static BufferedReader execute(String[] cmd) {
        try {
            // 创建ProcessBuilder对象
            ProcessBuilder processBuilder = new ProcessBuilder(cmd);

            // 执行命令并获取输出结果
            Process process = processBuilder.start();

            // 读取标准输出
            InputStream inputStream = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

            // 读取错误输出流
            InputStream errorStream = process.getErrorStream();
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(errorStream));

            // 启动线程处理输出流，避免阻塞
            new Thread(() -> {
                String line;
                try {
                    while ((line = reader.readLine()) != null) {
                        log.debug("stdout: " + line);  // 或者 log 输出
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();

            new Thread(() -> {
                String line;
                try {
                    while ((line = errorReader.readLine()) != null) {
                        log.error("stderr: " + line);  // 或者 log 输出
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();

            // 等待命令执行完成
            int exitCode = process.waitFor();
            log.debug("Exit Code: " + exitCode);
            return reader;
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return null;
        }
    }
}
