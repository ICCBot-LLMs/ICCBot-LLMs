package com.iscas.iccbot.utils;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

public class FridaHookManager {
    private static final Logger logger = LoggerFactory.getLogger(FridaHookManager.class);
    private static volatile FridaHookManager instance;
    private Socket socket;
    private BufferedWriter out;
    private BufferedReader in;
    private ExecutorService executor = Executors.newCachedThreadPool();
    private ConcurrentMap<String, CompletableFuture<String>> pendingRequests = new ConcurrentHashMap<>();
    private BlockingQueue<JsonObject> hookResults = new LinkedBlockingQueue<>();
    private BlockingQueue<JsonObject> sinkEvents = new LinkedBlockingQueue<>(); // 新增Sink事件队列
    private static final Gson gson = new Gson();
    private ScheduledExecutorService keepAliveExecutor = Executors.newSingleThreadScheduledExecutor();
    private static final int RECONNECT_INTERVAL = 5;
    private ConcurrentLinkedQueue<String> registeredSinks = new ConcurrentLinkedQueue<>(); // 已注册的Sink点

    private ScheduledExecutorService cmdExecutor = Executors.newScheduledThreadPool(4);

    private FridaHookManager(String host, int port) throws IOException {
        initializeConnection(host, port);
        startResponseListener();
    }

    public static FridaHookManager getInstance(String host, int port) throws IOException {
        if (instance == null) {
            synchronized (FridaHookManager.class) {
                if (instance == null) {
                    instance = new FridaHookManager(host, port);
                }
            }
        }
        return instance;
    }

    private void initializeConnection(String host, int port) throws IOException {
        socket = new Socket();
        socket.setKeepAlive(true);
        socket.setTcpNoDelay(true);
        socket.setSoTimeout(60000);

        try {
            socket.connect(new InetSocketAddress(host, port), 15000);
        } catch (ConnectException e) {
            logger.error("连接服务器失败: {}", e.getMessage());
            throw e;
        }

        out = new BufferedWriter(new OutputStreamWriter(
                socket.getOutputStream(), StandardCharsets.UTF_8));
        in = new BufferedReader(new InputStreamReader(
                socket.getInputStream(), StandardCharsets.UTF_8));

        keepAliveExecutor.scheduleAtFixedRate(() -> {
            try {
                if (socket.isConnected() && !socket.isClosed()) {
                    sendHeartbeat();
                }
            } catch (Exception e) {
                logger.error("心跳发送失败，触发重连: {}", e.getMessage());
                reconnect();
            }
        }, 10, 25, TimeUnit.SECONDS);
    }

    // 新增Sink注册方法
    public boolean registerSink(String sootSignature) {
        try {
            synchronized (out) {
                out.write("SINK|" + sootSignature + "\n");
                out.flush();
                logger.debug("已发送Sink注册请求: {}", sootSignature);
                return true;
            }
        } catch (IOException e) {
            logger.error("Sink注册失败: {}", e.getMessage());
            return false;
        }
    }

    private void sendHeartbeat() throws IOException {
        synchronized (out) {
            out.write("KEEPALIVE|PING\n");
            out.flush();
        }
    }

    public boolean setupHook(String sootSignature, long timeout, TimeUnit unit) {
        String requestId = generateRequestId(sootSignature);
        CompletableFuture<String> future = new CompletableFuture<>();
        pendingRequests.put(requestId, future);

        try {
            sendHookRequest(requestId, sootSignature);
            String response = future.get(timeout, unit);
            return validateHookResponse(response);
        } catch (TimeoutException e) {
            logger.error("操作超时: {}", sootSignature);
        } catch (Exception e) {
            logger.error("操作异常: {}", e.getMessage());
        } finally {
            pendingRequests.remove(requestId);
        }
        return false;
    }

    // 新增获取Sink事件方法
    public JsonObject getNextSinkEvent(long timeout, TimeUnit unit)
            throws InterruptedException {
        return sinkEvents.poll(timeout, unit);
    }

    public JsonObject getNextHookResult(long timeout, TimeUnit unit)
            throws InterruptedException {
        return hookResults.poll(timeout, unit);
    }

    private synchronized void sendHookRequest(String requestId, String method) throws IOException {
        String msg = String.format("HOOK|%s|%s\n", requestId, method);
        synchronized (out) {
            out.write(msg);
            out.flush();
            logger.debug("已发送请求: {}", msg.trim());
        }
    }

    private void startResponseListener() {
        executor.execute(() -> {
            while (!socket.isClosed()) {
                try {
                    String response = in.readLine();
                    if (response == null) {
                        logger.warn("连接已被服务器关闭");
                        reconnect();
                        break;
                    }
                    processResponse(response);
                } catch (SocketTimeoutException e) {
                    logger.debug("读取超时，连接保持");
                } catch (IOException e) {
                    if (!socket.isClosed()) {
                        logger.error("连接异常: {}", e.getMessage());
                        reconnect();
                    }
                    break;
                }
            }
        });
    }

    private void processResponse(String response) {
        // 处理心跳响应
        if (response.startsWith("KEEPALIVE|")) {
            return;
        }

        // 新增CMD响应处理
        if (response.startsWith("CMD|")) {
            String[] parts = response.split("\\|", 3);
            if (parts.length == 3) {
                String requestId = parts[1];
                String result = parts[2];
                CompletableFuture<String> future = pendingRequests.get(requestId);
                if (future != null) {
                    future.complete(result);
                    pendingRequests.remove(requestId);
                }
            }
            return;
        }

        // 处理全局Sink事件
        if (response.startsWith("GLOBAL|")) {
            handleGlobalEvent(response.substring(7));
            return;
        }

        // 处理系统消息
        if (response.startsWith("SUCCESS|") || response.startsWith("ERROR|") || response.startsWith("WARN|")) {
            logger.info("系统消息: {}", response);
            return;
        }

        String[] parts = response.split("\\|", 2);
        if (parts.length != 2) {
            logger.warn("收到异常响应: {}", response);
            return;
        }

        String requestId = parts[0];
        String jsonData = parts[1];

        // 处理hook结果数据
        if (jsonData.contains("\"class\"")) {
            try {
                JsonObject result = gson.fromJson(jsonData, JsonObject.class);
                hookResults.offer(result);
                logger.debug("收到Hook数据: {}", result);
            } catch (JsonSyntaxException e) {
                logger.error("无效的JSON格式: {}", jsonData);
            }
            return;
        }

        CompletableFuture<String> future = pendingRequests.get(requestId);
        if (future != null) {
            future.complete(jsonData);
            logger.debug("请求{}已完成", requestId);
        } else {
            logger.warn("收到未知请求ID的响应: {}", requestId);
        }
    }

    private void handleGlobalEvent(String jsonData) {
        try {
            JsonObject event = gson.fromJson(jsonData, JsonObject.class);
            if (event.has("type") && "sink".equals(event.get("type").getAsString())) {
                sinkEvents.offer(event);
                logger.warn("[Sink告警] 检测到敏感操作: {}.{}",
                        event.get("class").getAsString(),
                        event.get("method").getAsString());
            }
        } catch (JsonSyntaxException e) {
            logger.error("无效的全局事件格式: {}", jsonData);
        }
    }

    private synchronized void reconnect() {
        logger.info("尝试重新连接...");
        cleanup();
        try {
            TimeUnit.SECONDS.sleep(RECONNECT_INTERVAL);
            initializeConnection(socket.getInetAddress().getHostName(), socket.getPort());

            // 重连后重新注册所有Sink
            registeredSinks.forEach(sink -> {
                try {
                    synchronized (out) {
                        out.write("SINK|" + sink + "\n");
                        out.flush();
                    }
                } catch (IOException e) {
                    logger.error("Sink重新注册失败: {}", sink);
                }
            });

            startResponseListener();
            logger.info("重连成功");
        } catch (Exception e) {
            logger.error("重连失败: {}", e.getMessage());
        }
    }

    private boolean validateHookResponse(String response) {
        try {
            JsonObject json = gson.fromJson(response, JsonObject.class);
            boolean success = json.has("status") &&
                    "success".equals(json.get("status").getAsString());
            if (!success) {
                logger.error("操作失败: {}", json);
            }
            return success;
        } catch (JsonSyntaxException e) {
            logger.error("无效的响应格式: {}", response);
            return false;
        }
    }

    private String generateRequestId(String methodName) {
        return methodName.hashCode() + "-" +
                System.nanoTime() + "-" +
                Thread.currentThread().getId();
    }

    private synchronized void cleanup() {
        try {
            keepAliveExecutor.shutdownNow();
            executor.shutdownNow();

            if (in != null) in.close();
            if (out != null) out.close();
            if (socket != null) socket.close();

            pendingRequests.values().forEach(f ->
                    f.completeExceptionally(new SocketException("连接已关闭")));
            hookResults.clear();
            sinkEvents.clear();

            logger.info("连接资源已释放");
        } catch (IOException e) {
            logger.error("资源释放异常: {}", e.getMessage());
        }
        instance = null;
    }

    public boolean clearHooks() {
        try {
            synchronized (out) {
                out.write("CLEAR\n");
                out.flush();
                registeredSinks.clear();  // 清除本地注册记录
                logger.debug("已发送清除Hook请求");
                return true;
            }
        } catch (IOException e) {
            logger.error("清除Hook失败: {}", e.getMessage());
            return false;
        }
    }

    // 新增发送CMD命令的方法
    public CompletableFuture<String> sendCommand(String command, long timeout, TimeUnit unit) {
        String requestId = generateRequestId("CMD-" + command);
        CompletableFuture<String> future = new CompletableFuture<>();
        pendingRequests.put(requestId, future);

        try {
            synchronized (out) {
                out.write(String.format("CMD|%s|%s\n", requestId, command));
                out.flush();
                logger.debug("已发送CMD命令: {}", command);
            }
            cmdExecutor.schedule(() -> {
                if (!future.isDone()) {
                    future.completeExceptionally(new TimeoutException("CMD执行超时"));
                    pendingRequests.remove(requestId);
                }
            }, timeout, unit);
        } catch (IOException e) {
            future.completeExceptionally(e);
            pendingRequests.remove(requestId);
        }
        return future;
    }
}
