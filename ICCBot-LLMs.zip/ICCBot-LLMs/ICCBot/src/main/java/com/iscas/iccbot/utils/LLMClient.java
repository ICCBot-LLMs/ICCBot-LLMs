package com.iscas.iccbot.utils;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.IOException;
import java.util.List;

public class LLMClient {

    public static class RequestMessage {
        public String role;
        public String content;

        public RequestMessage(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class ApiResponse {
        public String id;
        public String object;
        public long created;
        public String model;
        public List<Choice> choices;
        public Usage usage;
        public String system_fingerprint;
    }

    public static class Choice {
        public int index;
        public ResponseMessage message;
        public String finish_reason;
    }

    public static class ResponseMessage {
        public String role;
        public String content;
        public String reasoning_content;
    }

    public static class Usage {
        public int prompt_tokens;
        public int completion_tokens;
        public int total_tokens;
    }

    public static class ResponseFormat {
        public String type;

        public ResponseFormat(String type) {
            this.type = type;
        }
    }

    public interface ChatCallback {
        void onSuccess(ApiResponse response);
        void onFailure(IOException e);
    }
}
