package com.iscas.iccbot.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class SiliconCloudClient {
    private static final Logger logger = LoggerFactory.getLogger(SiliconCloudClient.class);

    private static final String API_URL = "https://api.siliconflow.cn/v1/chat/completions";
    private static final String API_KEY = "";
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    private static SiliconCloudClient instance;
    private OkHttpClient client;
    private final ObjectMapper objectMapper;
    private List<RequestMessage> conversationHistory;

    // 配置参数
    private String model = "deepseek-ai/DeepSeek-R1";
    private boolean stream = false;
    private Integer maxTokens;
    private List<String> stop;
    private Double temperature;
    private Double topP;
    private Integer topK;
    private Double frequencyPenalty;
    private Integer n = 1;
    private ResponseFormat responseFormat = null;

    // 超时配置
    private long connectTimeout = 10;
    private long readTimeout = 30;
    private long writeTimeout = 30;

    /* 数据结构定义 */
    // 请求消息结构
    public static class RequestMessage {
        public String role;
        public String content;

        public RequestMessage(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }

    // 响应消息结构
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class ResponseMessage {
        public String role;
        public String content;
        public String reasoning_content;
    }

    // API响应结构
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class ApiResponse {
        public String id;
        public String object;
        public long created;
        public String model;
        public List<Choice> choices;
        public Usage usage;
        public String system_fingerprint;
    }

    public static class Choice {
        public int index;
        public ResponseMessage message;
        public String finish_reason;
    }

    public static class Usage {
        public int prompt_tokens;
        public int completion_tokens;
        public int total_tokens;
    }

    public static class ResponseFormat {
        public String type;
    }

    /* 单例实现 */
    private SiliconCloudClient() {
        rebuildHttpClient();
        this.objectMapper = new ObjectMapper()
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .setSerializationInclusion(JsonInclude.Include.NON_NULL);
        this.conversationHistory = new ArrayList<>();
    }

    public static synchronized SiliconCloudClient getInstance() {
        if (instance == null) {
            instance = new SiliconCloudClient();
        }
        return instance;
    }

    /* 核心方法 */
    public ApiResponse chat(String userMessage) throws IOException {
        // 添加用户消息
        conversationHistory.add(new RequestMessage("user", userMessage));

        // 构建请求
        RequestBody body = RequestBody.create(buildRequestBody(), JSON);
        Request request = new Request.Builder()
                .url(API_URL)
                .header("Authorization", "Bearer " + API_KEY)
                .post(body)
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Request failed: " + response.code() + " - " + response.message());
            }

            String responseBody = response.body().string();
            ApiResponse apiResponse = objectMapper.readValue(responseBody, ApiResponse.class);

            // 添加AI响应到历史
            if (apiResponse.choices != null && !apiResponse.choices.isEmpty()) {
                ResponseMessage msg = apiResponse.choices.get(0).message;
                conversationHistory.add(new RequestMessage("assistant", msg.content));
            }

            return apiResponse;
        }
    }

    /* 配置方法（链式调用） */
    public SiliconCloudClient model(String model) {
        this.model = model;
        return this;
    }

    public SiliconCloudClient maxTokens(Integer maxTokens) {
        this.maxTokens = maxTokens;
        return this;
    }

    public SiliconCloudClient temperature(Double temperature) {
        this.temperature = temperature;
        return this;
    }

    public SiliconCloudClient responseFormat(String type) {
        this.responseFormat = new ResponseFormat();
        this.responseFormat.type = type;
        return this;
    }


    // 其他配置方法（topP, topK等）可根据需要添加...
    public SiliconCloudClient topP(Double topP) {
        this.topP = topP;
        return this;
    }

    public SiliconCloudClient topK(Integer topK) {
        this.topK = topK;
        return this;
    }

    public SiliconCloudClient frequencyPenalty(Double frequencyPenalty) {
        this.frequencyPenalty = frequencyPenalty;
        return this;
    }

    public SiliconCloudClient n(Integer n) {
        this.n = n;
        return this;
    }

    public SiliconCloudClient stop(List<String> stop) {
        this.stop = stop;
        return this;
    }

    public SiliconCloudClient stream(boolean stream) {
        this.stream = stream;
        return this;
    }

    /* 超时配置 */
    public SiliconCloudClient connectTimeout(long seconds) {
        this.connectTimeout = seconds;
        rebuildHttpClient();
        return this;
    }

    public SiliconCloudClient readTimeout(long seconds) {
        this.readTimeout = seconds;
        rebuildHttpClient();
        return this;
    }

    public SiliconCloudClient writeTimeout(long seconds) {
        this.writeTimeout = seconds;
        rebuildHttpClient();
        return this;
    }

    public SiliconCloudClient timeout(long seconds) {
        return this.connectTimeout(seconds)
                .readTimeout(seconds)
                .writeTimeout(seconds);
    }

    private void rebuildHttpClient() {
        this.client = new OkHttpClient.Builder()
                .connectTimeout(connectTimeout, TimeUnit.SECONDS)
                .readTimeout(readTimeout, TimeUnit.SECONDS)
                .writeTimeout(writeTimeout, TimeUnit.SECONDS)
                .build();
    }

    /* 私有方法 */
    private String buildRequestBody() throws IOException {
        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put("model", this.model);
        requestMap.put("messages", convertToRequestMessages());
        requestMap.put("stream", this.stream);
        requestMap.put("max_tokens", this.maxTokens);
        requestMap.put("stop", this.stop);
        requestMap.put("temperature", this.temperature);
        requestMap.put("top_p", this.topP);
        requestMap.put("top_k", this.topK);
        requestMap.put("frequency_penalty", this.frequencyPenalty);
        requestMap.put("n", this.n);
        if (this.responseFormat != null) {
            requestMap.put("response_format", Collections.singletonMap("type", this.responseFormat.type));
        }

        return objectMapper.writeValueAsString(requestMap);
    }

    private List<Map<String, String>> convertToRequestMessages() {
        List<Map<String, String>> messages = new ArrayList<>();
        for (RequestMessage msg : conversationHistory) {
            Map<String, String> m = new HashMap<>();
            m.put("role", msg.role);
            m.put("content", msg.content);
            messages.add(m);
        }
        return messages;
    }

    /* 辅助方法 */
    public void resetConversation() {
        conversationHistory.clear();
    }

    public String getConversationHistory() {
        StringBuilder sb = new StringBuilder();
        for (RequestMessage msg : conversationHistory) {
            sb.append(String.format("[%s] %s\n", msg.role.toUpperCase(), msg.content));
        }
        return sb.toString();
    }

    public void printResponse(ApiResponse response) {
        if (response.choices != null && !response.choices.isEmpty()) {
            ResponseMessage msg = response.choices.get(0).message;
            logger.debug("=== 主要回复 ===");
            logger.debug(msg.content);

            if (msg.reasoning_content != null) {
                logger.debug("\n=== 推理过程 ===");
                logger.debug(msg.reasoning_content);
            }
        }

        if (response.usage != null) {
            logger.debug("\n=== Token使用 ===");
            logger.debug("输入: {}, 输出: {}, 总计: {}\n",
                    response.usage.prompt_tokens,
                    response.usage.completion_tokens,
                    response.usage.total_tokens);
        }
    }
}




