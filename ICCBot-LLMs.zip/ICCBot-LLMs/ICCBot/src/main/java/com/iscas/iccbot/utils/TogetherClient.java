package com.iscas.iccbot.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLHandshakeException;
import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TogetherClient extends LLMClient {
    private static final Logger logger = LoggerFactory.getLogger(TogetherClient.class);

    // 配置常量
    private static final String API_URL = "https://api.together.xyz/v1/chat/completions";
    private static final String API_KEY = "";
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final int MAX_RETRIES = 3;
    private static final long BASE_RETRY_INTERVAL_MS = 2000;
    private static final long MAX_RETRY_DELAY_MS = 30000;
    private static final ScheduledExecutorService retryExecutor = Executors.newSingleThreadScheduledExecutor();

    public static class RetryableException extends IOException {
        public RetryableException(String message) {
            super(message);
        }
    }

    private static TogetherClient instance;
    private OkHttpClient client;
    private final ObjectMapper objectMapper;
    private final List<RequestMessage> conversationHistory;

    // 配置参数
    private String model = "deepseek-ai/DeepSeek-R1";
    private boolean stream = false;
    private Integer maxTokens;
    private List<String> stop;
    private Double temperature;
    private Double topP;
    private Integer topK;
    private Double frequencyPenalty;
    private Integer n = 1;
    private ResponseFormat responseFormat = null;

    // 超时配置（调整为更合理的值）
    private long connectTimeout = 10;
    private long readTimeout = 60;
    private long writeTimeout = 15;

    private TogetherClient() {
        rebuildHttpClient();
        this.objectMapper = new ObjectMapper()
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .setSerializationInclusion(JsonInclude.Include.NON_NULL);
        this.conversationHistory = new CopyOnWriteArrayList<>();
    }

    public static synchronized TogetherClient getInstance() {
        if (instance == null) {
            instance = new TogetherClient();
        }
        return instance;
    }

    public ApiResponse chat(String userMessage) throws IOException {
        conversationHistory.add(new RequestMessage("user", userMessage));
        List<RequestMessage> contextSnapshot = new CopyOnWriteArrayList<>(conversationHistory);

        int attempt = 0;
        IOException lastException = null;

        while (attempt <= MAX_RETRIES) {
            try {
                ApiResponse response = executeSyncRequest(contextSnapshot);
                updateConversationHistory(response);
                return response;
            } catch (IOException e) {
                lastException = e;
                if (!isRetryable(e)) {
                    break;
                }

                if (attempt < MAX_RETRIES) {
                    long delay = calculateBackoffDelay(attempt);
                    logger.warn("同步请求失败（第{}/{}次重试，{}ms后重试）",
                            attempt + 1, MAX_RETRIES, delay);
                    try {
                        Thread.sleep(delay);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        throw new IOException("重试等待被中断", ie);
                    }
                }
                attempt++;
            }
        }

        throw lastException != null ?
                new IOException("请求失败，重试"+MAX_RETRIES+"次后仍不成功", lastException) :
                new IOException("未知错误");
    }

    public CompletableFuture<ApiResponse> chatAsync(String userMessage) {
        CompletableFuture<ApiResponse> future = new CompletableFuture<>();
        conversationHistory.add(new RequestMessage("user", userMessage));
        List<RequestMessage> contextSnapshot = new CopyOnWriteArrayList<>(conversationHistory);

        executeAsyncRequest(contextSnapshot, future, 0);
        return future;
    }

    private ApiResponse executeSyncRequest(List<RequestMessage> context) throws IOException {
        Request request = buildRequest(context);
        try (Response response = client.newCall(request).execute()) {
            validateResponse(response);
            return parseResponse(response, context);
        }
    }

    private void executeAsyncRequest(List<RequestMessage> context,
                                     CompletableFuture<ApiResponse> future,
                                     int retryCount) {
        Request request = buildRequest(context);
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onResponse(Call call, Response response) {
                try (response) {
                    validateResponse(response);
                    ApiResponse apiResponse = parseResponse(response, context);
                    updateConversationHistory(apiResponse);
                    future.complete(apiResponse);
                } catch (IOException e) {
                    handleAsyncFailure(e, context, future, retryCount);
                }
            }

            @Override
            public void onFailure(Call call, IOException e) {
                handleAsyncFailure(e, context, future, retryCount);
            }
        });
    }

    private Request buildRequest(List<RequestMessage> context) {
        try {
            RequestBody body = RequestBody.create(buildRequestBody(context), JSON);
            return new Request.Builder()
                    .url(API_URL)
                    .header("Authorization", "Bearer " + API_KEY)
                    .header("accept", "application/json")
                    .post(body)
                    .build();
        } catch (IOException e) {
            throw new RuntimeException("构建请求失败", e);
        }
    }

    private ApiResponse parseResponse(Response response, List<RequestMessage> context) throws IOException {
        String responseBody = response.body().string();
        ApiResponse apiResponse = objectMapper.readValue(responseBody, ApiResponse.class);
        processResponseContent(apiResponse);
        return apiResponse;
    }

    private void processResponseContent(ApiResponse apiResponse) {
        if (apiResponse.choices != null) {
            for (Choice choice : apiResponse.choices) {
                ResponseMessage msg = choice.message;
                if (msg != null && msg.content != null) {
                    parseThinkContent(msg);
                }
            }
        }
    }

    private void updateConversationHistory(ApiResponse apiResponse) {
        if (apiResponse.choices != null && !apiResponse.choices.isEmpty()) {
            ResponseMessage msg = apiResponse.choices.get(0).message;
            String assistantResponse = buildAssistantMessage(msg);
            conversationHistory.add(new RequestMessage("assistant", assistantResponse));
        }
    }

    private void handleAsyncFailure(IOException e,
                                    List<RequestMessage> context,
                                    CompletableFuture<ApiResponse> future,
                                    int retryCount) {
        if (retryCount < MAX_RETRIES && isRetryable(e)) {
            long delay = calculateBackoffDelay(retryCount);
            logger.warn("异步请求失败（第{}/{}次重试，{}ms后重试，原因：{}）",
                    retryCount + 1, MAX_RETRIES, delay, e.getMessage());
            scheduleRetry(context, future, retryCount, delay);
        } else {
            future.completeExceptionally(wrapFinalException(e));
        }
    }

    private Throwable wrapFinalException(IOException e) {
        return (e instanceof RetryableException) ?
                new IOException("超过最大重试次数（共" + MAX_RETRIES + "次）", e) :
                e;
    }

    private long calculateBackoffDelay(int retryCount) {
        long delay = (long) (BASE_RETRY_INTERVAL_MS * Math.pow(2, retryCount));
        return Math.min(delay, MAX_RETRY_DELAY_MS);
    }

    private void scheduleRetry(List<RequestMessage> context,
                               CompletableFuture<ApiResponse> future,
                               int retryCount,
                               long delay) {
        retryExecutor.schedule(() -> {
            logger.debug("执行第{}次重试，上下文长度：{}", retryCount + 1, context.size());
            executeAsyncRequest(context, future, retryCount + 1);
        }, delay, TimeUnit.MILLISECONDS);
    }

    private boolean isRetryable(IOException e) {
        return e instanceof SocketTimeoutException ||
                e instanceof ConnectException ||
                e instanceof SSLHandshakeException ||
                e instanceof RetryableException ||
                (e.getCause() != null && e.getCause() instanceof SocketTimeoutException);
    }

    private boolean isRetryable(int statusCode) {
        return statusCode == 429 || (statusCode >= 500 && statusCode < 600);
    }

    private void validateResponse(Response response) throws IOException {
        if (!response.isSuccessful()) {
            String errorBody = response.body().string();
            int statusCode = response.code();
            if (isRetryable(statusCode)) {
                throw new RetryableException("可重试的服务器错误：" + statusCode);
            }
            throw new IOException("请求失败：" + statusCode + " - " + errorBody);
        }
    }

    private String buildRequestBody(List<RequestMessage> messages) throws IOException {
        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put("model", this.model);
        requestMap.put("messages", convertToRequestMessages(messages));
        requestMap.put("temperature", this.temperature);
        requestMap.put("top_p", this.topP);
        requestMap.put("max_tokens", this.maxTokens);
        requestMap.put("stop", this.stop);
        requestMap.put("top_k", this.topK);
        requestMap.put("frequency_penalty", this.frequencyPenalty);
        requestMap.put("n", this.n);
        if (this.responseFormat != null) {
            requestMap.put("response_format", Collections.singletonMap("type", this.responseFormat.type));
        }

        return objectMapper.writeValueAsString(requestMap);
    }

    private List<Map<String, String>> convertToRequestMessages(List<RequestMessage> messages) {
        List<Map<String, String>> result = new ArrayList<>();
        for (RequestMessage msg : messages) {
            Map<String, String> m = new HashMap<>();
            m.put("role", msg.role);
            m.put("content", msg.content);
            result.add(m);
        }
        return result;
    }

    private void parseThinkContent(ResponseMessage msg) {
        String content = msg.content;
        Pattern pattern = Pattern.compile("<think>(.*?)</think>(.*)", Pattern.DOTALL);
        Matcher matcher = pattern.matcher(content);
        if (matcher.find()) {
            msg.reasoning_content = matcher.group(1).trim();
            msg.content = matcher.group(2).trim();
        } else {
            msg.reasoning_content = null;
        }
    }

    private String buildAssistantMessage(ResponseMessage msg) {
        StringBuilder sb = new StringBuilder();
        sb.append(msg.content);
        if (msg.reasoning_content != null && !msg.reasoning_content.isEmpty()) {
            sb.append("\n\n[推理过程]\n").append(msg.reasoning_content);
        }
        return sb.toString();
    }

    public void resetConversation() {
        conversationHistory.clear();
    }

    public String getConversationHistory() {
        StringBuilder sb = new StringBuilder();
        for (RequestMessage msg : conversationHistory) {
            sb.append(String.format("[%s]\n%s\n\n",
                    msg.role.toUpperCase(),
                    msg.content.replace("[推理过程]", "\n[推理过程]")));
        }
        return sb.toString();
    }

    public void printResponse(ApiResponse response) {
        if (response.choices != null && !response.choices.isEmpty()) {
            ResponseMessage msg = response.choices.get(0).message;

            logger.debug("=== 主要回复 ===");
            logger.debug(msg.content);

            if (msg.reasoning_content != null && !msg.reasoning_content.isEmpty()) {
                logger.debug("\n=== 推理过程 ===");
                logger.debug(msg.reasoning_content);
            }
        }

        if (response.usage != null) {
            logger.debug("\n=== Token使用 ===");
            logger.debug("输入: {}, 输出: {}, 总计: {}",
                    response.usage.prompt_tokens,
                    response.usage.completion_tokens,
                    response.usage.total_tokens);
        }
    }

    // 配置方法
    public TogetherClient model(String model) {
        this.model = model;
        return this;
    }

    public TogetherClient maxTokens(Integer maxTokens) {
        this.maxTokens = maxTokens;
        return this;
    }

    public TogetherClient temperature(Double temperature) {
        this.temperature = temperature;
        return this;
    }

    public TogetherClient responseFormat(String type) {
        this.responseFormat = new ResponseFormat(type);
        return this;
    }

    public TogetherClient topP(Double topP) {
        this.topP = topP;
        return this;
    }

    public TogetherClient topK(Integer topK) {
        this.topK = topK;
        return this;
    }

    public TogetherClient frequencyPenalty(Double frequencyPenalty) {
        this.frequencyPenalty = frequencyPenalty;
        return this;
    }

    public TogetherClient stop(List<String> stop) {
        this.stop = stop;
        return this;
    }

    public TogetherClient connectTimeout(long seconds) {
        this.connectTimeout = seconds;
        rebuildHttpClient();
        return this;
    }

    public TogetherClient readTimeout(long seconds) {
        this.readTimeout = seconds;
        rebuildHttpClient();
        return this;
    }

    public TogetherClient writeTimeout(long seconds) {
        this.writeTimeout = seconds;
        rebuildHttpClient();
        return this;
    }

    public TogetherClient timeout(long seconds) {
        return this.connectTimeout(seconds)
                .readTimeout(seconds)
                .writeTimeout(seconds);
    }

    private void rebuildHttpClient() {
        this.client = new OkHttpClient.Builder()
                .connectTimeout(connectTimeout, TimeUnit.SECONDS)
                .readTimeout(readTimeout, TimeUnit.SECONDS)
                .writeTimeout(writeTimeout, TimeUnit.SECONDS)
                .build();
    }
}
