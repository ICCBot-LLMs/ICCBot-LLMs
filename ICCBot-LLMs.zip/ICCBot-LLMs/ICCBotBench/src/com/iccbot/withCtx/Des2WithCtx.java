package com.iccbot.withCtx;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class Des2WithCtx extends Service {

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
