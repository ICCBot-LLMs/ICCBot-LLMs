package com.iccbot.withCtx;

import android.content.Context;
import android.content.Intent;

public class Utils {
	 public static void startIntent(Context ctx, Intent i){
	        //Call Context Related ICC
	        ctx.startActivity(i); 
	    }
}
