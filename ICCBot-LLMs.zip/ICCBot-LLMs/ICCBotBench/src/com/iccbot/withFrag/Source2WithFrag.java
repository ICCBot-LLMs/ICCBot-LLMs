package com.iccbot.withFrag;


import com.iccbot.R;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;

/**
 * Source2WithFrag to Des2WithFrag
 * 
 */

public class Source2WithFrag extends ActionBarActivity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.source2withfrag);
		
	}
}
